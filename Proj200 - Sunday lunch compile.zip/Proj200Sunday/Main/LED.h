#include <stm32f4xx.h>

void InitLED(void);