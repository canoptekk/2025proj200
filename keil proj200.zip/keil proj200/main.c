/*

-send keil output from LDR
-polling onto putty
-store onto array
-set a cut off,anything above is peak
-put array onto excel


putty layout sorted, plus find a way to install or test with the excel but think thats sorted
the instructions from pt worked well so far

make sure to change port information fto be what is now in main.h file
*/

#include "stm32f4xx.h"
#include <stdio.h>
#include "ADC.h"

void init_ADC(void)
{
	//Initiases the pins that need to be read for ADC
	RCC->AHB1ENR |= RCC_AHB1ENR_GPIOCEN | RCC_AHB1ENR_GPIOBEN | RCC_AHB1ENR_GPIOAEN; //enables all GPIO clocks A, B, and C
	ADC_input_port->MODER|=(3u<<(2*ADC_input_pin));	//ADC input pin is analogue mode (LDR)
	ADC_input_port_POT->MODER|=(3u<<(2*ADC_input_pin_POT));	//ADC input pin is analogue mode (POT)
	ADC_input_port_MIC->MODER|=(3u<<(2*ADC_input_pin_MIC));	//ADC input pin is analogue mode (MIC)
	
	//Initilisation for the LDR
	RCC->APB2ENR|=RCC_APB2ENR_ADC1EN;		//ADC clock enable
	ADC1->SQR1&=~ADC_SQR1_L;						//set number of conversions per sequence to 1
	ADC1->SQR3&=~ADC_SQR3_SQ1;					//clear channel select bits
	ADC1->SQR3|=ADC_Channel;						//set channel
	ADC1->CR2|=ADC_CR2_ADON;						//enable ADC
	}


unsigned short read_adc_LDR(void)
{
	ADC1->CR2|=ADC_CR2_SWSTART;				//start ADC conversion
	while((ADC1->SR&ADC_SR_EOC)==0){__NOP();}	//wait for ADC conversion complete
	return ADC1->DR;									//return converted value
}


/*---------------------------------------------------------------------------------------------------------


#include <math.h>  // For fabs()

//function to find the potential difference, 
float percentage_difference(float a, float b) {
    if (a == 0 && b == 0) return 0;  // Prevent division by zero
    
    return (fabs(a - b) / ((a + b) / 2.0)) * 100.0;
}




//in main, do when button b pressed


		float result_nonflip = percentage_difference(num1, num2);//potential difference between the two
		float result = 100 - result_nonflip ;//percentage of oxygenated blood 
		
    
    printf("Blood oxygen level: %.2f%%\n", result);//change to LCD display




-----------------------------------------------------------------------------*/

#define BUFFER_SIZE 10  // Define buffer size (adjustable)

typedef struct {
    uint16_t buffer[BUFFER_SIZE]; // Array to hold ADC values
    uint8_t head; // Index for writing (next free space)
    uint8_t tail; // Index for reading (oldest data)
    uint8_t count; // Number of stored elements
} CircularBuffer;

// Function prototypes
void buffer_init(CircularBuffer *cb);
uint8_t buffer_is_full(CircularBuffer *cb);
uint8_t buffer_is_empty(CircularBuffer *cb);
void buffer_write(CircularBuffer *cb, uint16_t data);
uint16_t buffer_read(CircularBuffer *cb);





void buffer_init(CircularBuffer *cb) {
    cb->head = 0;  // Start writing at index 0
    cb->tail = 0;  // Start reading at index 0
    cb->count = 0; // No data initially
}


uint8_t buffer_is_full(CircularBuffer *cb) {
    return (cb->count == BUFFER_SIZE); // Full when count reaches buffer size
}
uint8_t buffer_is_empty(CircularBuffer *cb) {
    return (cb->count == 0); // Empty when count is zero
}


void buffer_write(CircularBuffer *cb, uint16_t data) {
    if (!buffer_is_full(cb)) { // Only write if buffer is not full
        cb->buffer[cb->head] = data;  // Store data at current head position
        cb->head = (cb->head + 1) % BUFFER_SIZE; // Move head forward, wrap if needed
        cb->count++; // Increase stored data count
    }
}



uint16_t buffer_read(CircularBuffer *cb) {
    uint16_t data = 0;
    if (!buffer_is_empty(cb)) { // Only read if buffer is not empty
        data = cb->buffer[cb->tail]; // Read from the tail position
        cb->tail = (cb->tail + 1) % BUFFER_SIZE; // Move tail forward, wrap if needed
        cb->count--; // Decrease stored data count
    }
    return data; // Return the read value
}







/*
void ADC_Init(void);
uint16_t ADC_Read(void);
void UART2_Init(void);
void UART2_SendString(char *str);

int main(void) {
    char msg[50];
    
    UART2_Init();   // Initialize UART for debugging
    ADC_Init();     // Initialize ADC

    while (1) {
        uint16_t adc_value = ADC_Read(); // Read ADC
        float voltage = (adc_value * 3.3) / 4095; // Convert to voltage

        // Print the ADC value and voltage
        sprintf(msg, "ADC Value: %d, Voltage: %.2fV\r\n", adc_value, voltage);
        UART2_SendString(msg);

        for (volatile int i = 0; i < 100000; i++); // Small delay
    }
}

// 1. Configure ADC on PA0 (ADC1 Channel 0)
void ADC_Init(void) {
    RCC->APB2ENR |= RCC_APB2ENR_ADC1EN;  // Enable ADC1 Clock
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN; // Enable GPIOA Clock
    
    // Configure PA0 as analog mode
    GPIOA->MODER |= (3 << 0);  // Analog mode (11)
    
    ADC1->CR2 = 0; // Ensure ADC is disabled
    ADC1->SQR3 = 0; // First conversion in regular sequence is channel 0 (PA0)
    ADC1->SQR1 = 0; // Only one conversion in sequence
    ADC1->SMPR2 |= (7 << 0); // Maximum sample time for more accuracy
    
    ADC1->CR2 |= ADC_CR2_ADON; // Enable ADC
}

// 2. Start ADC conversion and return result
uint16_t ADC_Read(void) {
    ADC1->CR2 |= ADC_CR2_SWSTART; // Start conversion
    while (!(ADC1->SR & ADC_SR_EOC)); // Wait for conversion to complete
    return ADC1->DR; // Return ADC result
}

// 3. Initialize UART2 for debugging
void UART2_Init(void) {
    RCC->APB1ENR |= RCC_APB1ENR_USART2EN;  // Enable USART2 Clock
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN;   // Enable GPIOA Clock
    
    // Configure PA2 (TX) and PA3 (RX) in alternate function mode
    GPIOA->MODER |= (2 << 4) | (2 << 6); // Alternate function mode
    GPIOA->AFR[0] |= (7 << 8) | (7 << 12); // AF7 (USART2) for PA2 and PA3
    
    USART2->BRR = 0x0683; // 9600 baud rate
    USART2->CR1 |= USART_CR1_TE | USART_CR1_RE | USART_CR1_UE; // Enable TX, RX, and UART
}

// 4. Send a string over UART2
void UART2_SendString(char *str) {
    while (*str) {
        while (!(USART2->SR & USART_SR_TXE)); // Wait until TX is empty
        USART2->DR = *str++;
    }
}

*/