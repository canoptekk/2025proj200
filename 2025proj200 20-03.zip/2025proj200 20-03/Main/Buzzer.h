void OFF (char LED_BIT); //delcaring the OFF function to turn a LED pin/ pin off
void ON (char LED_BIT); //Declaring the On function to turn a LED pin/ pin on
void 	INIT_BUZZ (char LED_BIT);//Declaring the INIT_BUZZ function to initalise a buzzer