#ifndef _DAC_H
#define _DAC_H
#include <stm32f4xx.h>

#define DAC_port	GPIOA
#define DAC_pin		5
#define DAC_pinIR 4


void init_DAC(void);
void output_dac(unsigned short d);
void output_dac2(unsigned short d);
#endif
