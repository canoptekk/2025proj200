#include <stm32f4xx.h>

void Init_Sampling(void);

void Init_HoldButton(void);

void Init_BuzzerPitch(void);

void PWM_Init(void);