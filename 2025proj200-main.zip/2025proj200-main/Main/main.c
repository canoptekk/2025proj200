#include <stm32f4xx.h>	//allows the main to interact with external .h and .c files (start)
#include "PLL_Config.c"
#include "ADC.h"
#include "DAC.h"
#include "lcd.h"
#include "Timer.h"
#include "Buttons.h"
#include "LED.h"
#include "Buzzer.h"
#include <stdio.h>
#include "usart.h"
#include "main.h"		//end of includes

#define BUZZ_PIN 13	

int RedFlash = 0;		//holds current state of RedLED - (high or low)
int StartUpLock = 0;	//holds current state of start up loop (locked/unlocked)
int HoldTimer = 0;									//int for hold lock/release
int HoldRelease = 0;						
int ButtonMode = 0;							//int for the buttons a, b, c and d
int BuzzerDuration = 800;
int BuzzerARRValue = 0;
int BuzzerPSCValue = 0;
int LCDTopRow = 0;
int Debounce = 0;
int Wave = 0;
int Scailing = 0;
int HoldLCD = 0;
extern int POTVoltage;
extern int LEDDACVAL;
int DACVoltOut = 0;
int DACREDVoltOut = 0;
int DACIRVoltOut = 0;
float Array[] = {3697, 3685, 3673, 3660, 3660, 3656, 3613, 3556, 3485, 3470, 3400, 3314, 3242, 3170, 3113, 3014, 2955, 2856, 2851, 2584, 2512, 2398, 2326, 2198, 2084, 1969, 1870, 1669, 1611, 1482, 1383, 1383, 1254, 1197, 1039, 955, 797, 755, 626, 569, 498, 440, 354, 297, 198, 168, 126, 111, 69, 68, 40, 37, 34, 24, 31, 42, 47, 99, 126, 155, 186, 254, 297, 341, 411, 496, 570, 655, 846, 854, 969, 1165, 1170, 1240, 1397, 1454, 1655, 1697, 1868, 1984, 2113, 2227, 2313, 2412, 2489, 2613, 2727, 2856, 2942, 2999, 3128, 3213, 3271, 3371, 3470, 3485, 3514, 3584, 3628, 3642, 3685, 3710, 3673};
float TriangleArray[] = {2442, 2612, 2841, 2815, 3299, 3527, 3700, 3485, 3256, 3042, 2870, 2584, 2383, 2140, 1912, 1669, 1469, 1233, 984, 797, 554, 325, 111, 111, 297, 527, 784, 998, 1234, 1425, 1669, 1883, 2113, 2341, 2489, 2742, 3014, 3227, 3442, 3722, 3613, 3328, 2789, 2913, 2613, 2398, 2184, 1969, 1798, 1569, 1300, 1113, 841, 598, 455, 240, 40, 240, 426, 641, 898, 1183, 1369, 1611, 1855, 2069, 2284, 2455, 2698, 2927, 3141, 3356, 3571, 3656, 3428, 3199, 2970, 2756, 2541, 2326, 2112, 1868, 1625, 1425, 1197, 955, 725, 526, 297, 24, 155, 397, 626, 826, 1069, 1283, 1469, 1726, 1940, 2140, 2368};
float SquareArray[] = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,3723,3723,3723,3723,3723,3723,3723,3723,3723,3723,3723,3723,3723,3723,3723,3723,3723,3723,3723,3723,3723,3723,3723,3723,3723,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,3723,3723,3723,3723,3723,3723,3723,3723,3723,3723,3723,3723,3723,3723,3723,3723,3723,3723,3723,3723,3723,3723,3723,3723,3723};
unsigned int i;

int BumpCheck = 0;
int SampleCount = 0;
int BPM = 0;
int BPMCount = 0;
float BPMBuffer[] = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};	
float LEDVoltage[] = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
float IRLEDVoltage [] = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};

	
	

int main(void)
{
	//setups and configs
	//PLL_Config();	
	SystemCoreClockUpdate();
	RCC->AHB1ENR |= RCC_AHB1ENR_GPIOCEN | RCC_AHB1ENR_GPIOBEN | RCC_AHB1ENR_GPIOAEN | RCC_AHB1ENR_GPIOGEN;
	init_ADC();		//config ADC
	init_DAC();		//config DAC
	initLCD();		//config LCD
	InitLED();		//config LED
	InitBut();		//config Buttons
	init_USART(); //config usart
	INIT_BUZZ(BUZZ_PIN); //config Buzzer
	Init_BuzzerPitch();	//configs Delay for buzzer
	
	//End of setups and configs
	
	
	//testing for finger clip
	//GPIOA->BSRR |= 0x0030;		redundant - remove later
	output_dac(4095);
	output_dac2(700);
	
		// Blue Start up button
	while(1)	//forever while - allows program to repeat itself indefinite
	{
		
		StartUpLock = 0;	//resets StartUpLock value
		Debounce = 0;
		while(GPIOC->IDR	& (1<<13)){		//activates when blue button pressed
			
			//debounce
			if(Debounce < 100){
				Debounce++;
			}
			else{	
		StartUpLock++;	//increases value of int StartUpLock
		}                                             //while button is being pressed x will increase
	}
		if(0<StartUpLock&StartUpLock<100000){        //check if x is greater than 0 but less than 1 - run the code 
			
			//this provides a small animation like a heart beat when the system starts
		for(int x=0xC0; x<=0xCF; x++){
		 cmdLCD(x);
		putLCD(0xFF);																	//prints block tiles on the bottom row of the LCD left to right
	}
	
	for(int x=0xCF; x>=0xC0; x--){
		 cmdLCD(x);
		putLCD(' ');																	//prints blank tiles from right to left
	}
			
		Init_Sampling();	// Initialise Timer
		Init_HoldButton();	// Initialise Timer
		PWM_Init();	
	
		//Main loop			
		while(1)	//constantly runs program inside - restarts once complete
		{	
		if(LCDTopRow == 0){
			LCDTopRow = 1;
			
			//LCD display
			cmdLCD(LCD_LINE1);							//displays the heart rate and oxygen on the LCD (1 - 16)
			putLCD('H');	//(1-
			putLCD('R');
			putLCD('=');
			putLCD('1');
			putLCD('0');
			putLCD('6');			//writes msg onto the LCD
			putLCD('&');
			putLCD('O');
			putLCD('2');
			putLCD('=');
			putLCD('9');
			putLCD('8');
			putLCD('.');
			putLCD('7');
			putLCD('%');	//-16)
			
			//commands used to modify and update the ARR and PSC to change buzzer tone
			BuzzerARRValue = 0;
			BuzzerPSCValue = 0;
			Init_BuzzerPitch();
			
			cmdLCD(LCD_LINE2);
				putLCD('H');
				putLCD('E');
				putLCD('A');
				putLCD('R');
				putLCD('T');
				putLCD('R');
				putLCD('A');			//writes msg onto the LCD
				putLCD('T');
				putLCD('E');
				putLCD('=');
				putLCD('1');
				putLCD('0');
				putLCD('6');
				putLCD('B');
				putLCD('P');
				putLCD('M');
		}
		
		GPIOB->BSRR |= 0x0080; //turns on blue LED
			
		//Hold mode button input
		if(GPIOC->IDR	& (1<<13)){	//activates when blue button pressed
			
			if(Debounce < 100){	//timer to prevent debounce
				Debounce++;	//increases timer value
			}
			else{
			TIM3->CR1|=TIM_CR1_CEN;	//starts timer3
			Debounce = 0; //reset debounce
			}
		} else{
			TIM3->CR1&=~TIM_CR1_CEN;//stops timer3
			TIM3->CNT = 0;	//resets timer3's value back to 0
		}	
		
		
		if(	HoldRelease == 0){		//executes enveloped if not in hold mode
			
				//4 buttons
		if(GPIOG->IDR & (1<<0)){	//button A
			if(Debounce < 100){	//timer to prevent debounce
				Debounce++;		//increases timer value
			}
			else{
				Debounce = 0;			//resets debounce timer
				ButtonMode = 0;		//tells system what button was last placed 
			//commands used to modify and update the ARR and PSC to change buzzer tone
			BuzzerARRValue = 0;		//modifies buzzers ARR value to change its pitch
			BuzzerPSCValue = 0;
			Init_BuzzerPitch();		//recalculates the values used for the timer used for calculating pitch
			
			cmdLCD(LCD_LINE2);
				putLCD('H');
				putLCD('E');
				putLCD('A');
				putLCD('R');
				putLCD('T');
				putLCD('R');
				putLCD('A');			//writes msg onto the LCD
				putLCD('T');
				putLCD('E');
				putLCD('=');
				putLCD('1');
				putLCD('0');
				putLCD('6');
				putLCD('B');
				putLCD('P');
				putLCD('M');
		
		}	
		
		
		}
		if(GPIOG->IDR & (1<<1)){	//button B
			if(Debounce < 100){		//timer to prevent debounce
				Debounce++;			//increases timer value
			}
			else{
				Debounce = 0;		//resets debounce timer
			ButtonMode = 1;		//tells system what button was last placed 
				BuzzerARRValue = 1;		//modifies buzzers ARR value to change its pitch
				Init_BuzzerPitch();		//recalculates the values used for the timer used for calculating pitch
				cmdLCD(LCD_LINE2);
				putLCD('O');
				putLCD('X');
				putLCD('Y');
				putLCD('G');		//writes msg onto the LCD
				putLCD('E');
				putLCD('N');
				putLCD('=');
				putLCD('9');
				putLCD('8');
				putLCD('.');
				putLCD('7');
				putLCD('%');
				putLCD(' ');
				putLCD(' ');
				putLCD(' ');
				putLCD(' ');
				
				
			//When button B is pressed, the bottom row on the LCD will display OXYGEN and the O2 percentage
			//it will also play two buzzes to show it the second option
			
//-----------------------------blood oxygen test-----------------------------------------------

		int test_1 = 0;			//tests the first voltage
		int test_2 = 0;			//tests the second voltage
		
			output_dac(4095);
			output_dac2(0);
			for
			
			
		}
		
				}
			
					}
		

		if(GPIOG->IDR & (1<<2)){	//button C
			if(Debounce < 100){		//timer to prevent debounce
				Debounce++;
			}
			else{
				Debounce = 0;		//resets debounce timer
			ButtonMode = 2;	//tells system what button was last placed 
				BuzzerARRValue = 2;	//modifies buzzers ARR value to change its pitch
				Init_BuzzerPitch();		//recalculates the values used for the timer used for calculating pitch
				cmdLCD(LCD_LINE2);
				putLCD('H');
				putLCD('U');
				putLCD('M');
				putLCD('I');
				putLCD('D');
				putLCD('I');
				putLCD('T');		//writes msg onto the LCD
				putLCD('Y');
				putLCD('=');
				putLCD('8');
				putLCD('9');
				putLCD('%');
				putLCD(' ');
				putLCD(' ');
				putLCD(' ');
				putLCD(' ');
			//When button C is pressed, the bottom row on the LCD will display HUMIDITY and the percentage
			//it will also play 3 buzzes to show it the third option
		}}
		if(GPIOG->IDR & (1<<3)){	//button D
			if(Debounce < 100){		//timer to prevent debounce
				Debounce++;			//increases timer value
			}
			else{
				Debounce = 0;		//resets debounce timer
			ButtonMode = 3;	//tells system what button was last placed 
			BuzzerARRValue = 3;		//modifies buzzers ARR value to change its pitch
				Init_BuzzerPitch();		//recalculates the values used for the timer used for calculating pitch
				cmdLCD(LCD_LINE2);
				putLCD('M');
				putLCD('O');
				putLCD('V');
				putLCD('E');
				putLCD('M');
				putLCD('E');
				putLCD('N');				//writes msg onto the LCD
				putLCD('T');
				putLCD('=');
				putLCD('2');
				putLCD('7');
				putLCD('.');
				putLCD('6');
				putLCD('m');
				putLCD('m');
				putLCD(' ');
			//When button D is pressed, the bottom row on the LCD will display MOVEMENT and the distance in milimeters
			//it will also play four buzzes to show it the fourth option
		}
	}
	
	
	//DAC Stuff - currently disabled for testing LED input (modify later)
	/*
		//changes the DAC output depending on the current mode
		if(ButtonMode == 0){		//button A pressed
			DACVoltOut = POTVoltage/1000;	//stores the voltage value of from the POT onto an int
			output_dac(DACVoltOut);			//outputs the voltage value of the POT onto the DAC
		}else if(ButtonMode == 1){		//button B pressed
			output_dac2(Array[Wave]);			//send straight to DAC (DAC pin should replicate ADC pin)
				Wave++;	//increases the current point on the wave
				if(Wave >= 99){		//used to measure how many samples are needed to be produced 
					Wave=0;}		//resets sample array
		}else if(ButtonMode == 2){		//button C pressed
			output_dac2(TriangleArray[Wave]);	//outputs triangle wave to the DAC
			Wave++;		//increases the current point on the wave
				if(Wave >= 99){		//used to measure how many samples are needed to be produced 
					Wave=0;}	//resets sample array
		}else if(ButtonMode == 3){		//button D pressed
			output_dac(SquareArray[Wave]);
			Wave++;
				if(Wave >= 99){
					Wave=0;}		//resets sample array
		}
	*/
}


}
}
}
}
//output_dac(ADC_DATA_LDR);			//send straight to DAC (DAC pin should replicate ADC pin)


//TIMER 2 INTERRUPT SERVICE ROUTINE - Samples ADC/Flashes RedLED
void TIM2_IRQHandler(void)			
{
		TIM2->SR&=~TIM_SR_UIF;				//clear interrupt flag in status register
	
	//turn on buzzer 
		TIM5->CR1|=TIM_CR1_CEN;	//currently goes off only at start
		
	//display current mode on UART
		CurrentMode();		//dispays current mode onto the UART
	//Read values from ADC
	
		HRPuTTyDisplay();
		//POTPuTTyDisplay();		//reads ADC value from POT and sends it to the UART
		//LDRPuTTyDisplay();		//reads ADC value from LDR and sends it to the UART
		//MICPuTTyDisplay();		//reads ADC value from MIC and sends it to the UART
	
	//---------------------BPM--------------------------	
	
		//HRnumber, SampleCount, BPM
		//collects samples at 100hz over the course of 6 seconds
	int HRnumber = read_adc_HR();
	if(SampleCount <= 600){	// 100hz = 100 samples a second, * 6 = 600 samples over 6 seconds
		BPMBuffer[SampleCount] = HRnumber;		//saves current value from the ADC onto the current place in the buffer
		SampleCount ++;		//increases current place in the cyclebuffer
		}else{
			BPM = 0;
			//BPMCount = 0;
			BumpCheck = 0;
			for(int BPMTotal = 0; SampleCount > BPMTotal; SampleCount--){	//resets buffer placement back to the start ('head')
				if (BPMBuffer[SampleCount] >= 0x9B2 & BumpCheck == 0){ //checks if signal is large enough to be counted as a bump as well as checks if said bump has already been counted
				BPM++;	
				BumpCheck = 1;
				}
				if(BPMBuffer[SampleCount] < 0x9B2 & BumpCheck == 1){//resets 'bumpcheck' once bump has ended
				BumpCheck = 0;
				}
			}
			BPM = BPM * 10;	//multiplys sample over minute for BPM
			BPMDisplay(); //displays BPM onto putty (see UART.c)			
		BPMBuffer[SampleCount] = HRnumber;	//saves current value from the ADC onto the current place in the buffer
		}
		
	//----------------------print BPM to LCD---------------
		int testvalue = 45278;
		for(int k = 0; k < 1000; k++){}
		
    char asciiStr[7];           // Array to hold the ASCII string (4 digits + null terminator)
    // Loop to extract each digit from the number and convert to ASCII
    for (int i = 7; i >= 0; i--)  // For an 8-digit number, loop from index 7 to 0
    {
        int digit = testvalue % 10;           // Extract the last digit
        asciiStr[i] = digit + '0';         // Convert digit to ASCII and store in array
        testvalue /= 10;                      // Remove the last digit
    }

   // 

	int BPM_value = 0;
		
		cmdLCD(LCD_LINE2);
		
	while(BPM_value<8)//writes full value
	{
		if(BPM_value<=4){
			BPM_value++;
		}else{
			for(int k = 0; k < 1000; k++){}
			putLCD(asciiStr[BPM_value]);//writes current ascii character from asciiStr into the terminal
			BPM_value++;	//increases the value of LDRValue which changes the current character in asciiStr to the next in the list
			__NOP();
		}
		}
			
		asciiStr[6] = '\0';  // Null-terminate the string
		
		putLCD(' ');
		putLCD('B');
		putLCD('P');
		putLCD('M');
	}
	
	//----------------------------------------------------------------------------------
	//Changes the Brightness of the LED/IRLED in the finger clip
		
/*		DACIRVoltOut = (700+((LEDDACVAL/1.207)-230.86));
		DACREDVoltOut = (700+(LEDDACVAL/1.207));	
		
		if(SquareArray > 0){
			output_dac(4095);
		}else{
		output_dac2(4095);
		}
	//----------------------------------------------------------------------------------
	
		GPIOB->BSRR |= 0x4000;	//turns RedLED on
		for(int c = 0; c < 2000; c++);
		GPIOB->BSRR |= 0x40000000; //turns RedLED off
}*/



//TIMER 3 Hold Mode SERVICE ROUTINE
void TIM3_IRQHandler(void)			
{
	
	if (HoldRelease == 0){
		HoldRelease = 1;
		TIM2->CR1 &= ~TIM_CR1_CEN;	//disables timer 2 (prevents samples being taken)	
		GPIOB->BSRR |= 0x40000000;	//turns off red LED
		if(HoldLCD == 0){
		cmdLCD(LCD_LINE2);	//moves curser to row 2
		putLCD(' ');	//fills space on screen with a blank
    putLCD(' ');//fills space on screen with a blank
    putLCD(' ');//fills space on screen with a blank
    putLCD(' ');//fills space on screen with a blank
    putLCD(' ');//fills space on screen with a blank
    putLCD(' ');//fills space on screen with a blank
    putLCD('H');//writes 'hold' msg onto bottom level of the LCD
    putLCD('O');
    putLCD('L');
    putLCD('D');
    putLCD(' ');//fills space on screen with a blank
    putLCD(' ');//fills space on screen with a blank
    putLCD(' ');//fills space on screen with a blank
    putLCD(' ');//fills space on screen with a blank
    putLCD(' ');//fills space on screen with a blank
    putLCD(' ');//fills space on screen with a blank
		HoldLCD = 1;
		}
	}else{
		HoldRelease = 0;	//sets hold mode to release
		LCDTopRow = 0;
		TIM2->CR1 |= TIM_CR1_CEN; //resumes timer (sampling)
		cmdLCD(0x01);	//wipes the LCD of characters
		HoldLCD = 0;
		}
	
	
	TIM3->SR&=~TIM_SR_UIF;				//clear interrupt flag in status register
	TIM3->CR1 &= ~TIM_CR1_CEN;	//disables timer 3
	while(GPIOC->IDR	& (1<<13)){	//prevents system from reading the input to lock as part of the input to unlock
		}
}


//Buzzer timer
void TIM5_IRQHandler(void){	//Pitch of buzzer
	TIM5->SR&=~TIM_SR_UIF;	//clear interrupt flag in status register
	
	if(i<BuzzerDuration){
		GPIOB->ODR ^=(1<<13);	//turn on buzzer
		i++;
		
	}else{
		TIM5->CR1 &= ~TIM_CR1_CEN;	//turns off timer 4 - (Buzzer Pitch)
		TIM5->CNT = 0;	//resets timer4's value back to 0
		i = 0;
	}
	
}

/*commands used for Buzzer
//turn on buzzer 
TIM5->CR1|=TIM_CR1_CEN;

//turn off buzzer
TIM5->CR1 &= ~TIM_CR1_CEN;

//commands used to modify and update the ARR and PSC to change buzzer tone
			BuzzerARRValue = 1;
			BuzzerPSCValue = 0;
			Init_BuzzerPitch();
*/